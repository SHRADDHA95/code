package com.robotservice.constants;

public enum LightColor {
	GREEN,
	RED;
}
