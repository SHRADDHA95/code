package com.robotservice.constants;

public interface RobotConstants {
	Double MAX_CAPICITY=10.0;
	Double MAX_DISTANCE=5.0;
	Double MIN_CHARGING_ALERT=15.0;
}
