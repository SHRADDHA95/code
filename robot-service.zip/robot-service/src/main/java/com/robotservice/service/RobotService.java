package com.robotservice.service;

public interface RobotService {
	void walkingWithWeight(Double distance,Double weight);
	void displayPrice(int barcode);

	
	
}
